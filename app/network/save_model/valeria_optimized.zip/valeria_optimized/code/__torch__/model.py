class LSTMWW(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  layernorm : __torch__.torch.nn.modules.normalization.LayerNorm
  lstm : __torch__.torch.nn.modules.rnn.LSTM
  classifier : __torch__.torch.nn.modules.linear.Linear
  def forward(self: __torch__.model.LSTMWW,
    x: Tensor) -> Tensor:
    classifier = self.classifier
    lstm = self.lstm
    layernorm = self.layernorm
    _0 = (layernorm).forward(x, )
    batch_size = ops.prim.NumToTensor(torch.size(_0, 1))
    _1 = int(batch_size)
    _2 = torch.zeros([1, int(batch_size), 128], dtype=None, layout=None, device=torch.device("cpu"), pin_memory=False)
    hx = torch.to(_2, dtype=6, layout=0, device=torch.device("cpu"))
    _3 = torch.zeros([1, _1, 128], dtype=None, layout=None, device=torch.device("cpu"), pin_memory=False)
    hx0 = torch.to(_3, dtype=6, layout=0, device=torch.device("cpu"))
    _4 = (classifier).forward((lstm).forward(_0, hx, hx0, ), )
    return _4
