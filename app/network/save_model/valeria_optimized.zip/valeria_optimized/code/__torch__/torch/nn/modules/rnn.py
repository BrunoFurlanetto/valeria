class LSTM(Module):
  __parameters__ = ["weight_ih_l0", "weight_hh_l0", "bias_ih_l0", "bias_hh_l0", ]
  __buffers__ = []
  weight_ih_l0 : Tensor
  weight_hh_l0 : Tensor
  bias_ih_l0 : Tensor
  bias_hh_l0 : Tensor
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.rnn.LSTM,
    argument_1: Tensor,
    hx: Tensor,
    hx0: Tensor) -> Tensor:
    bias_hh_l0 = self.bias_hh_l0
    bias_ih_l0 = self.bias_ih_l0
    weight_hh_l0 = self.weight_hh_l0
    weight_ih_l0 = self.weight_ih_l0
    _0 = [hx, hx0]
    _1 = [weight_ih_l0, weight_hh_l0, bias_ih_l0, bias_hh_l0]
    _2, input, _3 = torch.lstm(argument_1, _0, _1, True, 1, 0.10000000000000001, False, False, False)
    return input
